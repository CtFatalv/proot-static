# proot static build

### amd64, arm64 built from the official [repo](https://github.com/proot-me/proot)
### riscv64 built from this [repo](https://github.com/Jer6y/proot)

## Suppored architectures

- amd64
- arm64
- riscv64
